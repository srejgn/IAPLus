# R Code to do IRT analysis for scale Reading
rm(list=ls())
if(!require("TAM")){install.packages("TAM")}
library("TAM")
setwd("C:/Users/egonzalez/OneDrive - Educational Testing Service/Temp/ItemAnalysis/VideoExample")
if (file.exists("TwoBlocks_PersonScores.csv")) {file.remove("TwoBlocks_PersonScores.csv")}
if (file.exists("TwoBlocks_IRTStats.csv")) {file.remove("TwoBlocks_IRTStats.csv")}
if (file.exists("TwoBlocks.RData")) {file.remove("TwoBlocks.RData")}
responses <- read.csv("TwoBlocks_responses.csv")
# checks for all NA and constant responses
WhichAreNA <- sapply(X = responses[1:25], FUN = function(i) {all(is.na(i))})
AreNotNA <- names(Filter(isFALSE, WhichAreNA))
ColVariance <- (sapply(X = responses[,AreNotNA], FUN = function(i) {var(x = i, na.rm=TRUE)}))
UseTheseItems <- names(ColVariance[ColVariance > 0])
message("\nThese items were taken out because of NO responses.")
print(names(Filter(isTRUE,WhichAreNA)))
message("\nThese items were taken out because of NO variance.")
print(names(ColVariance[ColVariance == 0]))
results <- TAM::tam.mml(responses[,UseTheseItems], irtmodel="PCM", pweights=responses$pwgt,
     pid=responses$CaseSeq,control=list(nodes=seq(-4,4,len=41),convD=.001,conv=.001,convM=.001),
     constraint="cases")
abilities<- tam.wle(results)
write.csv(results$item_irt,"TwoBlocks_IRTstats.csv")
personstats<-cbind(results$person,abilities[5:6])
write.csv(personstats,"TwoBlocks_PersonScores.csv")
q("no")
